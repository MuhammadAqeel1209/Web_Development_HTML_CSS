// Write on terminal npm init to make jason file 

//Write npm install "name" for any dependencies lije slugify 

//npm install slugify@version number

// npm install nodemon --save-dev as a devDependencies
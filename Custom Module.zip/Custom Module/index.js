// const average = require("./module");
// console.log(average([3,4]))

const mod = require("./module");
console.log(mod.avg([3,4]))
console.log(mod.name)
console.log(mod.repo)

console.log("This index page");



